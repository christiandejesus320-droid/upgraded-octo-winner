# ⚙️ Setup Guide — Cómo usar este repositorio en GitHub
### NovaXCo Prompt Vault

---

## 🚀 Pasos para subir a GitHub

### Paso 1 — Crear el repositorio
1. Ve a [github.com](https://github.com) e inicia sesión
2. Click en **"New repository"** (botón verde)
3. Configura:
   - **Repository name:** `novaxco-prompts`
   - **Description:** `🛍️ Vault de prompts IA para NovaXCo — ecommerce, contenido, copy y automatización`
   - **Visibility:** Private (recomendado) o Public
   - ✅ Marca "Add a README file"
4. Click **"Create repository"**

---

### Paso 2 — Estructura de carpetas a crear

```
novaxco-prompts/
├── README.md                              ← (ya incluido)
├── product-photography/
│   └── apparel.md                         ← Prompts Midjourney
├── video-content/
│   └── hooks-scripts.md                   ← TikTok/Reels scripts
├── copywriting/
│   └── product-ads-email.md               ← Copy ventas
├── system-prompts/
│   └── novaxco-agents.md                  ← GPT custom prompts
├── product-research/
│   └── validation-sourcing.md             ← Research & sourcing
├── ai-automation/
│   └── make-zapier-flows.md               ← Automatizaciones
├── customer-service/
│   └── responses-objections.md            ← Atención al cliente
└── analytics-strategy/
    └── metrics-scaling.md                 ← Análisis y escala
```

---

### Paso 3 — Subir archivos

**Opción A (más simple — desde GitHub web):**
1. Entra a tu repositorio
2. Click "Add file" → "Upload files"
3. Arrastra los archivos `.md`
4. Click "Commit changes"

**Opción B (desde terminal con Git):**
```bash
git clone https://github.com/tu-usuario/novaxco-prompts.git
cd novaxco-prompts
# Copia todos los archivos aquí
git add .
git commit -m "feat: add initial NovaXCo prompt vault"
git push origin main
```

---

### Paso 4 — Activar GitHub Pages (opcional)

Si quieres que el repositorio sea navegable como web:
1. Settings → Pages
2. Source: "Deploy from a branch"
3. Branch: main → /root
4. Save

URL resultante: `https://tu-usuario.github.io/novaxco-prompts`

---

## 📌 Cómo usar los prompts

### Con Claude (recomendado)
1. Abre el archivo `.md` del prompt que necesitas
2. Copia el prompt
3. Rellena los campos entre `[corchetes]`
4. Pégalo en Claude

### Con ChatGPT Custom GPT
1. Ve a `system-prompts/novaxco-agents.md`
2. Copia el agente que necesitas
3. Úsalo como system prompt de tu GPT

### Con Midjourney
1. Ve a `product-photography/apparel.md`
2. Copia el prompt del producto
3. Reemplaza `[COLOR]` y parámetros
4. Pégalo en Discord: `/imagine [prompt]`

---

## 🔄 Cómo mantener el repositorio actualizado

```markdown
Cada vez que crees un prompt nuevo que funcione:
1. Documentarlo en el archivo correspondiente
2. Añadir fecha y contexto
3. Commit con mensaje descriptivo:
   "feat: add EMS belt lifestyle prompt"
   "fix: update hoodie prompt for better realism"
   "docs: add new TikTok hook templates"
```

---

## 🏷️ Etiquetas de status recomendadas

```markdown
🟢 PROBADO Y FUNCIONA — Prompt validado con buenos resultados
🟡 EN PRUEBA — Generando resultados, recopilando data
🔴 NO FUNCIONA — Descartado, sirve de referencia negativa
⚪ SIN PROBAR — Nuevo, pendiente de test
```

---

*Este repositorio es el sistema nervioso creativo de NovaXCo.  
Actualízalo cada vez que algo funcione.*
