# 📦 Product Research Prompts
### NovaXCo · Validación · Sourcing · AliExpress

---

## 🔍 PROMPT 001 — Encontrar Producto Ganador

```
Actúa como un experto en dropshipping para el mercado latinoamericano.

Quiero encontrar el próximo producto ganador para mi tienda NovaXCo
(nicho: EMS fitness + streetwear premium, mercado: RD y LATAM).

Analiza estas categorías y dame 5 productos con alto potencial:
CATEGORÍA: [fitness / moda / bienestar / tecnología portátil]

Para cada producto, dime:
1. Nombre del producto
2. Problema que resuelve (específico)
3. ¿Por qué funcionaría en LATAM ahora mismo?
4. ¿Está saturado o hay ventana de oportunidad?
5. Precio costo estimado AliExpress / precio venta sugerido / margen
6. Potencial viral TikTok (1-10) y por qué
7. ¿Complementa el catálogo actual de NovaXCo? Sí/No

Sé específico. No me des categorías, dame nombres de productos reales.
```

---

## 🧪 PROMPT 002 — Validar Producto Específico

```
Ayúdame a validar este producto antes de añadirlo a NovaXCo:

PRODUCTO: [nombre del producto]
URL ALIEXPRESS: [url si tienes]
PRECIO COSTO: [precio]
PRECIO VENTA PLANIFICADO: [precio]

Evalúa en escala 1-10:
□ Claridad del problema que resuelve
□ Urgencia del dolor de la audiencia
□ Facilidad de demostración en video (30 seg)
□ Potencial before/after visual
□ Competencia en LATAM (10 = sin competencia)
□ Margen de ganancia (10 = margen excelente)
□ Facilidad de sourcing (rating + reviews + volumen)
□ Compatibilidad con marca NovaXCo

PUNTUACIÓN TOTAL: /80
RECOMENDACIÓN: GO / NO-GO / EVALUAR MEJOR

Si es GO: dame plan de lanzamiento de 7 días.
Si es NO-GO: dame alternativa similar que sí funcione.
```

---

## 🏭 PROMPT 003 — Evaluar Proveedor AliExpress

```
Ayúdame a evaluar si este proveedor de AliExpress es confiable para dropshipping.

DATOS DEL PROVEEDOR:
- Nombre tienda: [nombre]
- Rating: [X/5]
- Total de ventas: [número]
- Años en plataforma: [años]
- Producto específico - órdenes: [número]
- Tiempo de envío ofrecido: [días]

PREGUNTAS CLAVE A EVALUAR:
1. ¿El rating ≥ 4.5? 
2. ¿Hay reviews con fotos de compradores reales?
3. ¿Hay quejas de calidad en reviews recientes?
4. ¿El proveedor responde mensajes? (crítico)
5. ¿Tiene opción de ePacket o envío con tracking a LATAM?
6. ¿Acepta mensajes personalizados o packaging custom?

RESULTADO: 
- Score de confiabilidad: /100
- ¿Usar como proveedor principal? Sí/No/Probar primero
- Alternativas recomendadas si aplica
```

---

## 📊 PROMPT 004 — Análisis de Competencia

```
Analiza la competencia de NovaXCo para [producto específico] en [país/región].

Busca y analiza:
1. ¿Quién más vende esto en LATAM/RD? (nombres de tiendas si conoces)
2. ¿A qué precio lo venden?
3. ¿Qué les falta en su marketing? (oportunidad para nosotros)
4. ¿Qué hacen bien que podemos aprender?
5. ¿Hay espacio para NovaXCo con posicionamiento premium?

ESTRATEGIA DE DIFERENCIACIÓN:
Basado en el análisis, ¿cómo debería posicionar NovaXCo este producto
de forma que sea difícil de copiar?

Dame 3 ángulos de diferenciación específicos.
```

---

## 💰 PROMPT 005 — Calculadora de Margen

```
Calcula la rentabilidad completa de este producto para NovaXCo:

COSTOS:
- Precio AliExpress: $[X]
- Envío AliExpress a RD/LATAM: $[X] (promedio $3-8)
- DSers/Shopify fees: $[X] (aproximado)
- Costo de devoluciones estimado: [X]% de ventas

INGRESOS:
- Precio de venta planificado: $[X]
- Tasa de conversión esperada: [X]%

MARKETING:
- ¿Con ads o sin ads? [especifica]
- Budget de ads diario si aplica: $[X]
- ROAS objetivo: [X]x

CALCULA:
1. Margen bruto por venta: $[X] y [X]%
2. Break-even si hay ads
3. Ganancia neta por venta con ads
4. ¿Cuántas ventas diarias para llegar a $100/día? $500/día?
5. Recomendación: ¿vale la pena?
```

---

## 🎯 PROMPT 006 — Plan de Lanzamiento de Producto

```
Crea un plan de lanzamiento de 14 días para este nuevo producto en NovaXCo:

PRODUCTO: [nombre]
PRECIO DE VENTA: [precio]
MERCADO OBJETIVO: [descripción]
PRESUPUESTO INICIAL: [0 / $50 / $100 / más]

PLAN SEMANA 1 (Orgánico puro):
- Día 1: [acción específica]
- Día 2: [acción específica]
...

PLAN SEMANA 2 (Con datos):
- Basado en resultados semana 1, ¿qué escalar?
- ¿Cuándo introducir ads si corresponde?

MÉTRICAS A REVISAR cada 2 días:
□ Views por video
□ Engagement rate
□ Clics al perfil/bio
□ Ventas directas

CRITERIO DE ÉXITO semana 1:
¿Qué resultado mínimo indica que el producto tiene potencial?

CRITERIO DE ABANDONO:
¿En qué momento cortar y pasar al siguiente producto?
```

---

## 🗂️ TEMPLATE — Ficha de Producto NovaXCo

```markdown
## FICHA DE PRODUCTO — [NOMBRE]

**Fecha de evaluación:** [fecha]
**Status:** EN EVALUACIÓN / ACTIVO / PAUSADO / DESCARTADO

### Info básica
| Campo | Detalle |
|---|---|
| URL AliExpress | [url] |
| Proveedor | [nombre] |
| Rating proveedor | ⭐ /5 |
| Órdenes del producto | [número] |

### Economía
| Campo | Valor |
|---|---|
| Costo AliExpress | $[X] |
| Costo envío | $[X] |
| Precio venta | $[X] |
| Margen bruto | [X]% |

### Evaluación de contenido
- ¿Se puede demostrar en 30 seg? Sí/No
- Potencial viral TikTok: /10
- Hook más fuerte identificado: [describir]

### Notas
[observaciones adicionales]
```

---

*Carpeta: `product-research/` · Actualizado por @novaxco*
