# 💬 Copywriting Prompts
### NovaXCo · Producto / Ads / Email / Shopify

---

## 🛒 COPY DE PRODUCTO — Shopify

### Prompt: Descripción de Producto Completa
```
Eres un copywriter experto en ecommerce para mercado latinoamericano.

Escribe la descripción completa de producto para Shopify con:

PRODUCTO: [nombre]
CATEGORÍA: [ropa / dispositivo EMS / accesorio]
BENEFICIOS CLAVE: [lista]
AUDIENCIA: [descripción]
PRECIO: [precio]
ESTÉTICA DE MARCA: dark luxury premium streetwear

Estructura obligatoria:
1. Headline principal (máximo 10 palabras, orientado a beneficio)
2. Párrafo de apertura (2-3 líneas, conecta emocionalmente)
3. Beneficios en bullets (5-7 puntos, formato: emoji + beneficio concreto)
4. Especificaciones técnicas (tabla)
5. Garantía y confianza (envío, devolución)
6. CTA final urgente

Tono: premium, directo, sin exageraciones baratas.
Idioma: español dominicano/latinoamericano natural.
```

---

### Ejemplo Generado — EMS Pro Belt™
```
# EMS Pro Belt™ — Activa cada fibra muscular en 20 minutos

El entrenamiento que no requiere el gym.
Tecnología de estimulación muscular eléctrica usada por atletas de élite,
ahora disponible directo a tu puerta.

✅ Estimulación profunda de músculos abdominales
✅ Sesiones de 20-30 minutos equivalen a 200 abdominales
✅ Úsalo en casa, trabajo o viajando
✅ 6 modos de intensidad ajustables
✅ Apto para principiantes y avanzados
✅ Batería recargable USB-C
✅ Resultados visibles desde la semana 2-3

| Especificación | Detalle |
|---|---|
| Modos | 6 niveles de intensidad |
| Batería | 1200mAh · USB-C |
| Material | Silicona médica + neopreno |
| Tallas | S/M · L/XL |
| Envío | 7-15 días a toda RD y LATAM |

🔒 Pago 100% seguro · Envío tracked · Garantía 30 días

[COMPRAR AHORA — Oferta limitada]
```

---

## 📱 COPY PARA ADS

### Prompt: Facebook/Instagram Ad Copy
```
Eres un media buyer experto en Meta Ads para ecommerce latinoamericano.

Crea 3 variaciones de copy para ad de [Facebook/Instagram] para:

PRODUCTO: [nombre]
OBJETIVO: [tráfico / conversión / remarketing]
AUDIENCIA FRÍA / TIBIA / CALIENTE: [especifica]
PRESUPUESTO IMPLÍCITO: [bajo/medio/alto ticket]

Por cada variación incluye:
- Headline (máximo 40 caracteres)
- Primary text (máximo 125 caracteres para preview)
- Descripción (máximo 25 caracteres)
- CTA button: [Comprar ahora / Más información / Ver oferta]

Variación 1: Orientada a DOLOR
Variación 2: Orientada a BENEFICIO/ASPIRACIÓN
Variación 3: Orientada a URGENCIA/ESCASEZ

Tono: directo, sin spam, premium pero accesible.
```

---

### Prompt: TikTok Ad Script (UGC style)
```
Escribe un script de TikTok Ad estilo UGC (User Generated Content) para:

PRODUCTO: [nombre]
DURACIÓN: [15/30 segundos]
PERSONA: [hombre/mujer, edad aproximada, interés]

El script debe:
- Sonar como una persona real, no una marca
- Tener un hook problemático los primeros 2 segundos
- Mostrar el producto de forma natural
- Incluir resultado o prueba visual
- CTA orgánico al final (no forzado)

Incluye stage directions: [acción visual], [texto en pantalla]
```

---

## 📧 EMAIL MARKETING

### Prompt: Email de Bienvenida (Post-compra)
```
Escribe un email de bienvenida post-compra para cliente de NovaXCo.

CONTEXTO:
- Acaba de comprar [producto]
- Primera vez comprando
- Marca: dark premium streetwear / fitness

El email debe:
1. Confirmar su compra con entusiasmo genuino (no robótico)
2. Dar tracking info placeholder
3. Qué esperar (días de envío)
4. Tip de uso del producto
5. Invitar a seguir en TikTok/Instagram
6. Pedir review/reseña cuando llegue
7. Código descuento segunda compra

Tono: premium pero cercano. Como una marca que se preocupa de verdad.
Asunto del email: [proponer 3 opciones de asunto con emojis]
```

---

### Prompt: Email de Carrito Abandonado
```
Escribe secuencia de 3 emails para carrito abandonado NovaXCo:

PRODUCTO ABANDONADO: [nombre]
PRECIO: [precio]

Email 1 (1 hora después): Recordatorio suave
- Asunto curioso, no agresivo
- "Olvidaste algo" angle
- Mostrar producto
- Sin descuento aún

Email 2 (24 horas después): Urgencia + Social Proof
- Asunto más directo
- Stock limitado angle
- Añadir 1-2 reseñas
- Ofrecer descuento pequeño (5-10%)

Email 3 (72 horas después): Última oportunidad
- Asunto urgente
- Oferta expira hoy
- Descuento mayor o bonus
- CTA muy claro

Cada email: máximo 150 palabras. Directo. Premium.
```

---

## 🔖 COPY PARA FICHAS DE PRODUCTO

### Template de Título de Producto (SEO + Conversión)
```
Formato: [Marca] [Nombre Producto] [Característica Principal] — [Beneficio]

Ejemplos:
✅ "NovaXCo EMS Pro Belt™ — Estimulación Muscular Profesional en Casa"
✅ "NovaXCo Heavyweight Hoodie — Oversized Premium Streetwear"
✅ "NovaXCo EMS Arm Toner — Tonifica Brazos en 20 Minutos"
```

### Meta Description (SEO)
```
Prompt para meta description:
"Escribe una meta description de 155 caracteres para [producto].
Incluye: beneficio principal, audiencia, y CTA.
Optimizada para SEO latinoamericano.
Sin exageraciones. Premium y directo."
```

---

## 📋 PROMPT MAESTRO — Copy Completo de Tienda
```
Eres el CMO y head copywriter de NovaXCo (novaxcowear.com).

La marca es: dark luxury premium streetwear + fitness EMS devices.
Mercado: República Dominicana y Latinoamérica.
Voz de marca: premium, directa, auténtica, sin exageraciones baratas.

Crea el copy completo para [sección de tienda]:
- [Hero section / About / Product page / FAQ / Policy / etc.]

Incluye variaciones A/B cuando sea relevante.
Prioriza conversión sobre creatividad.
```

---

*Carpeta: `copywriting/` · Actualizado por @novaxco*
