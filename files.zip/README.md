# 🛍️ NovaXCo Prompt Vault
### novaxcowear.com — Repositorio Oficial de Prompts

> Colección completa de prompts de IA para operar, escalar y dominar NovaXCo: producto, contenido, ads, copy, atención al cliente y más.

---

## 🗂️ Estructura del Repositorio

```
novaxco-prompts/
├── 📸 product-photography/       → Prompts Midjourney para fotos de producto
├── 🎬 video-content/             → Hooks, scripts y estructura TikTok/Reels/Shorts
├── 💬 copywriting/               → Copy de producto, ads, emails y landing
├── 🤖 ai-automation/             → Prompts para automatizaciones con IA
├── 🧠 customer-service/          → Respuestas y manejo de objeciones
├── 📦 product-research/          → Validación y sourcing de productos AliExpress
├── 📊 analytics-strategy/        → Análisis de métricas y decisiones de escala
└── 🔧 system-prompts/            → GPT custom y agentes de IA para NovaXCo
```

---

## 🏪 Sobre NovaXCo

| Campo | Detalle |
|---|---|
| 🌐 Tienda | [novaxcowear.com](https://novaxcowear.com) |
| 🛒 Modelo | Dropshipping 100% (AliExpress → DSers → Shopify) |
| 🎯 Mercado | República Dominicana + Latinoamérica |
| 🏋️ Nicho | Ropa EMS fitness & wellness / Streetwear premium |
| 🧢 Hero Product | EMS Pro Belt™ |
| 🎨 Estética | Dark luxury · Neon aqua & violet / Gold accents |

---

## ⚡ Quick Start — Prompts más usados

| Tipo | Archivo | Uso |
|---|---|---|
| 📸 Foto producto hoodie | `product-photography/apparel.md` | Midjourney |
| 🎬 Hook viral TikTok | `video-content/hooks.md` | CapCut / TikTok |
| 💬 Copy producto | `copywriting/product-copy.md` | Shopify / Ads |
| 🤖 Agente NovaXCo GPT | `system-prompts/novaxco-agent.md` | Claude / ChatGPT |

---

## 🛠️ Stack de Herramientas

- **Tienda:** Shopify (Tinker theme)
- **Sourcing:** AliExpress + DSers
- **Contenido:** TikTok + CapCut + Reels + Shorts
- **IA Imagen:** Midjourney v6
- **IA Texto:** Claude + ChatGPT
- **Automatización:** Make.com / Zapier
- **Análisis:** Google Analytics + Shopify Analytics

---

*Mantenido por el equipo NovaXCo · Actualizado constantemente*
