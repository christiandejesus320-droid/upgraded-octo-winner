# 🎬 Video Content Prompts
### NovaXCo · TikTok / Reels / Shorts

> Hooks, scripts y estructura para contenido viral de producto.  
> Meta: 2-3 videos por producto por día.

---

## 🪝 HOOKS — Primeros 3 Segundos

### Hooks de Dolor/Problema
```
"Si todavía haces [ACCIÓN NEGATIVA], estás perdiendo dinero/tiempo/resultados..."
"El 90% de personas que quieren [RESULTADO] cometen este error..."
"Nadie te dijo esto sobre [PRODUCTO/TEMA]..."
"Por qué tu [PROBLEMA] no mejora aunque hagas todo bien..."
"Esto que te voy a mostrar cambió mi [RESULTADO] en [TIEMPO]..."
```

### Hooks de Revelación/Secreto
```
"POV: Descubres el producto que [RESULTADO ESPECÍFICO]..."
"Este producto existe y nadie lo conoce en [PAÍS/REGIÓN]..."
"Cómo logré [RESULTADO] sin [SACRIFICIO COMÚN]..."
"La razón por la que [AUDIENCIA] no logra [RESULTADO]..."
"Encontré algo que [COMPETENCIA/ALTERNATIVA] no quiere que sepas..."
```

### Hooks NovaXCo Específicos (EMS + Streetwear)
```
"Si quieres marcar abdomen sin pasar horas en el gym, mira esto..."
"Este cinturón EMS hizo lo que 3 meses de gym no lograron..."
"POV: Tu hoodie llega y es exactamente como en la foto..."
"La ropa que todos piensan que es cara pero no lo es..."
"Cómo se ve esto puesto en la vida real [mostrar producto]..."
```

---

## 📝 SCRIPTS COMPLETOS

### Script 001 · EMS Pro Belt — Problema/Solución (30-45 seg)
```
[HOOK - 0-3 seg]
"Si llevas meses intentando marcar abdomen y no ves resultados, esto es para ti."

[PROBLEMA - 3-8 seg]  
"El problema no es el ejercicio. Es que no estás estimulando el músculo correctamente."

[SOLUCIÓN - 8-20 seg]
"El EMS Pro Belt envía impulsos eléctricos directamente al músculo.
Lo mismo que usan los atletas profesionales.
Puedes usarlo mientras trabajas, mientras ves Netflix, en cualquier momento."

[PRUEBA SOCIAL - 20-30 seg]
"Miles de personas en [región] ya lo tienen.
Los resultados hablan solos."

[CTA - 30-35 seg]
"Link en bio. Envío a toda [región]. Hoy con descuento."
```

---

### Script 002 · Hoodie Oversized — Estética/Lifestyle (15-30 seg)
```
[HOOK - 0-3 seg]
"Esta hoodie acaba de llegar y tengo que mostrártela."

[REVEAL - 3-15 seg]
[Mostrar packaging → desempacar → mostrar calidad de tela → ponérsela]
"Mira el peso de la tela. Mira el fit."

[DIFERENCIADOR - 15-22 seg]
"Esto no es fast fashion. Es heavyweight premium.
Y el precio no es lo que crees."

[CTA - 22-30 seg]
"Link en bio. Stock limitado."
```

---

### Script 003 · Comparación / VS (20-30 seg)
```
[HOOK]
"Gym 3 meses vs EMS Pro Belt 4 semanas. Esto es lo que nadie compara."

[COMPARACIÓN]
Gym tradicional:
❌ 1-2 horas diarias
❌ Requiere equipo
❌ Resultados lentos en abdomen

EMS Pro Belt:
✅ 20-30 minutos
✅ Lo usas en casa
✅ Estimulación muscular directa

[CTA]
"Tú decides. Link en bio."
```

---

### Script 004 · Unboxing Premium (30-45 seg)
```
[HOOK]
"Rate mi unboxing de NovaXCo 1-10..."

[PROCESO]
- Mostrar caja/packaging
- Abrir lentamente con buena música de fondo
- Primer contacto con el producto
- Detalle de calidad (tela, acabados, etc.)
- Versión puesta/en uso

[REACCIÓN GENUINA]
"Sinceramente, [reacción real sobre calidad/precio/fit]"

[CTA]
"Link directo en bio. Envío a [región]."
```

---

## 🎵 ESTRUCTURA TÉCNICA DE VIDEO

### Formato TikTok/Reels
```
Duración ideal:    15-30 segundos (para alcance)
Ratio:             9:16 vertical
Resolución:        1080x1920
FPS:               30fps mínimo (60fps para slow-mo)
Texto en pantalla: Primeros 3-5 segundos (refuerza hook)
Música:            Trending en TikTok (buscar semanal)
Hashtags:          Mix: nicho + trending + ubicación
```

### Estructura Visual
```
0-3 seg:    Hook visual fuerte (movimiento o texto impactante)
3-10 seg:   Desarrollo del problema o contexto
10-20 seg:  Solución / Producto en acción
20-28 seg:  Prueba social o resultado
28-30 seg:  CTA claro y directo
```

---

## 📊 PROMPT PARA GENERAR HOOKS CON IA

```
Actúa como un experto en contenido viral de TikTok para ecommerce.

Mi producto es: [NOMBRE PRODUCTO]
Beneficio principal: [BENEFICIO]
Audiencia: [DESCRIPCIÓN AUDIENCIA]
País/Región: [REGIÓN]

Genera 10 hooks virales para los primeros 3 segundos de video.
Cada hook debe:
- Crear curiosidad inmediata
- Hablar de un dolor real de la audiencia
- Ser máximo 10 palabras
- Funcionar sin ver el producto primero

Formatos a incluir: pregunta, afirmación bold, POV, comparación, secreto revelado.
```

---

## 🔄 PROMPT PARA GENERAR SCRIPT COMPLETO CON IA

```
Eres un copywriter experto en TikTok para ecommerce dropshipping en Latinoamérica.

PRODUCTO: [nombre]
PROBLEMA QUE RESUELVE: [descripción]
AUDIENCIA OBJETIVO: [descripción]
DURACIÓN TARGET: [15/30/45/60 segundos]
TONO: [urgente / educativo / lifestyle / comparación]

Escribe un script completo de TikTok con:
1. Hook (0-3 seg) - máximo impacto
2. Problema (3-8 seg) - dolor real
3. Solución (8-20 seg) - producto como héroe
4. Prueba social (20-28 seg)
5. CTA (últimos 3-5 seg)

Incluye indicaciones de [TEXTO EN PANTALLA] y [ACCIÓN VISUAL] en cada sección.
Lenguaje: español natural latinoamericano, sin formalismos.
```

---

*Carpeta: `video-content/` · Actualizado por @novaxco*
