# 📸 Product Photography Prompts
### NovaXCo · Midjourney v6

> Todos los prompts están optimizados para Midjourney v6 con estética dark premium streetwear.  
> Parámetros base: `--ar 9:16 --style raw --v 6 --q 2`

---

## 🧥 APPAREL — Ropa & Streetwear

### 001 · Hoodie Oversized (Flagship)
```
Product photography of a [COLOR] heavyweight oversized hoodie,
front and back view, displayed on an invisible mannequin,
shot in a minimalist urban studio with a dark concrete wall background,
natural side lighting with one soft key light,
slight shadows on the wall, grain film texture,
shot on Sony A7IV 35mm lens, f/2.8, realistic fabric texture
showing slight wrinkles and weight, no CGI look,
no studio lights visible, editorial streetwear style,
cinematic mood, dark and premium aesthetic,
logo placeholder on chest left side and full back print area
--ar 9:16 --style raw --v 6 --q 2
```
**Variables:** Reemplaza `[COLOR]` → `pink` / `black` / `cream` / `navy` / `olive`

---

### 002 · Hoodie On-Model (Dark Studio)
```
Editorial fashion photography of a male model wearing a [COLOR]
oversized heavyweight hoodie, urban dark studio background,
moody side lighting, concrete floor, slight fog atmosphere,
streetwear editorial style, cinematic grain, Sony A7IV 50mm f/1.8,
premium dark aesthetic, hands in pockets, slight downward gaze,
logo visible on chest, back view alternate shot
--ar 9:16 --style raw --v 6 --q 2
```

---

### 003 · Hoodie Flat Lay Premium
```
Flat lay product photo of a [COLOR] oversized heavyweight hoodie,
dark textured surface, shot from directly above (top-down 90°),
one dramatic side light source creating deep shadows,
editorial luxury fashion style, film grain texture,
accessories: [white sneakers / sunglasses / minimal accessories] nearby,
no wrinkles forced, natural fabric fall, Sony A7IV macro lens
--ar 1:1 --style raw --v 6 --q 2
```

---

### 004 · Joggers / Sweatpants
```
Product photography of [COLOR] heavyweight jogger sweatpants,
front and side view, invisible mannequin display,
dark minimalist studio, concrete background,
dramatic low side lighting, film grain, cinematic shadows,
waistband and cuff detail visible, realistic fabric texture,
no CGI, editorial streetwear mood, premium dark aesthetic
--ar 9:16 --style raw --v 6 --q 2
```

---

### 005 · Full Set / Outfit
```
Fashion editorial photography, full streetwear outfit:
[COLOR] oversized hoodie + matching joggers set,
worn by male model, dark urban environment,
moody cinematic lighting, fog machine effect subtle,
shot on Sony A7IV 35mm, f/2.0, film grain overlay,
premium luxury streetwear aesthetic, dark background,
brand logo visible on chest
--ar 9:16 --style raw --v 6 --q 2
```

---

## 💪 EMS FITNESS PRODUCTS

### 006 · EMS Belt — Hero Product Shot
```
Product photography of a black high-tech EMS muscle stimulator belt,
floating/levitating on dark background with subtle blue electric glow,
electric arc particles around the device, dark premium studio,
dramatic lighting from below, metallic and silicone texture detail,
no hands visible, tech product photography style,
Sony A7IV macro lens, sharp focus on device details,
cinematic dark aesthetic, neon blue accent lighting
--ar 9:16 --style raw --v 6 --q 2
```

---

### 007 · EMS Belt — Lifestyle In-Use
```
Lifestyle fitness photography of a fit athletic person wearing
a black EMS stimulator belt on their abs,
dark gym environment, dramatic side lighting,
slight blue electric glow effect on belt,
cinematic grain, moody athletic aesthetic,
Sony A7IV 35mm f/2.0, realistic skin texture,
no CGI effects, authentic athletic lifestyle
--ar 9:16 --style raw --v 6 --q 2
```

---

### 008 · EMS Device Pack Shot (E-commerce)
```
Clean product photography of black EMS fitness device
on pure dark charcoal background,
three-quarter angle view showing all details,
soft product lighting, slight reflection on surface,
premium tech gadget photography style,
sharp focus on all surfaces, metallic and soft-touch texture,
no shadows harsh, e-commerce ready image
--ar 1:1 --style raw --v 6 --q 2
```

---

## 🎨 VARIACIONES DE ESTÉTICA

### Estética A — Dark Luxury (Principal NovaXCo)
```
...dark concrete background, neon aqua accent lighting,
violet rim light, premium luxury streetwear aesthetic,
cinematic grain film texture, editorial fashion photography...
```

### Estética B — Amiri-Inspired (Gold Edition)
```
...near-black background, warm gold accent lighting,
single dramatic key light, luxury high fashion editorial,
slight vignette on edges, film grain, no studio equipment visible...
```

### Estética C — Urban Gritty
```
...urban alley background night, natural street lighting,
motion blur background, sharp product/model focus,
authentic streetwear culture photography...
```

---

## 📐 Parámetros de Referencia

| Parámetro | Valor | Uso |
|---|---|---|
| `--ar 9:16` | Vertical | TikTok / Stories / Reels |
| `--ar 1:1` | Cuadrado | Feed Instagram / Shopify |
| `--ar 16:9` | Horizontal | Banner / YouTube |
| `--style raw` | Sin filtro Midjourney | Más realista |
| `--v 6` | Versión 6 | Máxima calidad actual |
| `--q 2` | Calidad máxima | Más detalle |
| `--no logo` | Excluir | Quitar logos específicos |

---

## 🔄 Workflow Recomendado

```
1. Genera 4 variaciones con el prompt base
2. Selecciona la mejor con /upscale (U1-U4)
3. Usa /vary (subtle) para pequeños ajustes
4. Exporta en alta resolución
5. Edita en CapCut / Canva para añadir logo NovaXCo
```

---

*Carpeta: `product-photography/` · Actualizado por @novaxco*
